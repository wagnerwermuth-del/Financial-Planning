import React, { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { ChevronRight, ChevronLeft, User, Heart, Users, DollarSign, Target, Clock, FileText, MessageCircle } from 'lucide-react'
import './App.css'

function App() {
  const [currentSection, setCurrentSection] = useState(0)
  const [formData, setFormData] = useState({
    // Seção 1: Perfil do Cliente
    nomeCompleto: '',
    dataNascimento: '',
    profissao: '',
    estadoCivil: '',
    regimeCasamento: '',
    regimeCasamentoOutro: '',
    esportePreferido: '',
    hobbie: '',
    
    // Seção 2: Cônjuge
    nomeConjuge: '',
    dataNascimentoConjuge: '',
    profissaoConjuge: '',
    pilarFinanceiro: '',
    
    // Seção 3: Dependentes
    dependentes: [{ nome: '', grauParentesco: '', grauParentescoOutro: '', dataNascimento: '', profissao: '' }],
    
    // Seção 4: Patrimônio e Renda
    salarios: '',
    gastos: '',
    rendaTotal: '',
    distribuicaoLucros: '',
    alugueis: '',
    outrasRendas: '',
    outrasRendasDescricao: '',
    patrimonioRelevante: '',
    patrimonioForaXP: '',
    dividas: '',
    
    // Seção 5: Experiência e Perfil de Investidor
    jaInveste: '',
    ondeInveste: '',
    grauConhecimento: '',
    toleranciaRisco: '',
    reacaoCrises: '',
    
    // Seção 6: Objetivos Financeiros
    objetivoPrincipal: '',
    prazoDefinido: '',
    rentabilidadeEsperada: '',
    buscaRenda: '',
    
    // Seção 7: Liquidez e Necessidades Específicas
    precisaLiquidez: '',
    tempoInvestido: '',
    restricoesProdutos: '',
    
    // Seção 8: Tributação e Planejamento Sucessório
    estrategiasFiscais: '',
    planejamentoSucessorio: '',
    testamento: '',
    
    // Seção 9: Comportamento e Relacionamento
    comunicacaoPreferida: '',
    frequenciaAtualizacao: '',
    decisaoInvestimento: ''
  })

  const sections = [
    { 
      title: 'Perfil do Cliente', 
      icon: User, 
      description: 'Informações pessoais básicas' 
    },
    { 
      title: 'Cônjuge', 
      icon: Heart, 
      description: 'Dados do cônjuge/companheiro(a)' 
    },
    { 
      title: 'Dependentes', 
      icon: Users, 
      description: 'Informações sobre dependentes' 
    },
    { 
      title: 'Patrimônio e Renda', 
      icon: DollarSign, 
      description: 'Situação financeira atual' 
    },
    { 
      title: 'Experiência e Perfil de Investidor', 
      icon: Target, 
      description: 'Conhecimento e experiência em investimentos' 
    },
    { 
      title: 'Objetivos Financeiros', 
      icon: Target, 
      description: 'Metas e expectativas' 
    },
    { 
      title: 'Liquidez e Necessidades Específicas', 
      icon: Clock, 
      description: 'Necessidades de liquidez e restrições' 
    },
    { 
      title: 'Tributação e Planejamento Sucessório', 
      icon: FileText, 
      description: 'Aspectos fiscais e sucessórios' 
    },
    { 
      title: 'Comportamento e Relacionamento', 
      icon: MessageCircle, 
      description: 'Preferências de comunicação' 
    }
  ]

  const updateFormData = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const addDependente = () => {
    setFormData(prev => ({
      ...prev,
      dependentes: [...prev.dependentes, { nome: '', grauParentesco: '', grauParentescoOutro: '', dataNascimento: '', profissao: '' }]
    }))
  }

  const updateDependente = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      dependentes: prev.dependentes.map((dep, i) => 
        i === index ? { ...dep, [field]: value } : dep
      )
    }))
  }

  const removeDependente = (index) => {
    setFormData(prev => ({
      ...prev,
      dependentes: prev.dependentes.filter((_, i) => i !== index)
    }))
  }

  const nextSection = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1)
    }
  }

  const prevSection = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1)
    }
  }

  const progress = ((currentSection + 1) / sections.length) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-sm border-b border-green-500/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                <span className="text-black font-bold text-sm">L</span>
              </div>
              <h1 className="text-2xl font-bold text-white">
                liberta <span className="text-green-500">investimentos</span>
              </h1>
            </div>
            <div className="text-green-400 text-sm">
              Seção {currentSection + 1} de {sections.length}
            </div>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="bg-black/30 p-4">
        <div className="container mx-auto">
          <Progress value={progress} className="h-2 bg-gray-800" />
          <p className="text-green-400 text-sm mt-2 text-center">
            {Math.round(progress)}% concluído
          </p>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              {React.createElement(sections[currentSection].icon, {
                className: "w-12 h-12 text-green-500"
              })}
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">
              {sections[currentSection].title}
            </h2>
            <p className="text-gray-400">
              {sections[currentSection].description}
            </p>
          </div>

          {/* Form Card */}
          <Card className="bg-gray-900/50 border-green-500/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-green-400 text-xl">
                📋 {sections[currentSection].title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Renderizar seção atual */}
              {currentSection === 0 && (
                <PerfilClienteSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 1 && (
                <ConjugeSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 2 && (
                <DependentesSection 
                  formData={formData} 
                  updateFormData={updateFormData}
                  addDependente={addDependente}
                  updateDependente={updateDependente}
                  removeDependente={removeDependente}
                />
              )}
              {currentSection === 3 && (
                <PatrimonioRendaSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 4 && (
                <ExperienciaInvestidorSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 5 && (
                <ObjetivosFinanceirosSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 6 && (
                <LiquidezNecessidadesSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 7 && (
                <TributacaoSucessorioSection formData={formData} updateFormData={updateFormData} />
              )}
              {currentSection === 8 && (
                <ComportamentoRelacionamentoSection formData={formData} updateFormData={updateFormData} />
              )}
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <Button 
              onClick={prevSection}
              disabled={currentSection === 0}
              variant="outline"
              className="border-green-500/50 text-green-400 hover:bg-green-500/10"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Anterior
            </Button>
            
            {currentSection === sections.length - 1 ? (
              <Button 
                onClick={() => {
                  console.log('Dados do formulário:', formData)
                  alert('Questionário enviado com sucesso!')
                }}
                className="bg-green-500 hover:bg-green-600 text-black font-semibold"
              >
                Enviar Questionário
              </Button>
            ) : (
              <Button 
                onClick={nextSection}
                className="bg-green-500 hover:bg-green-600 text-black font-semibold"
              >
                Próximo
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/50 border-t border-green-500/20 mt-16">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-gray-400 text-sm">
            <p>© 2024 Liberta Investimentos - Questionário de Perfil do Cliente</p>
            <p className="mt-1">Sua liberdade financeira começa aqui</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Componentes das seções (serão implementados na próxima fase)
const PerfilClienteSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="nomeCompleto" className="text-green-400">Nome completo *</Label>
        <Input
          id="nomeCompleto"
          value={formData.nomeCompleto}
          onChange={(e) => updateFormData('nomeCompleto', e.target.value)}
          className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
          placeholder="Digite seu nome completo"
        />
      </div>
      
      <div>
        <Label htmlFor="dataNascimento" className="text-green-400">Data de nascimento *</Label>
        <Input
          id="dataNascimento"
          type="date"
          value={formData.dataNascimento}
          onChange={(e) => updateFormData('dataNascimento', e.target.value)}
          className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
        />
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="profissao" className="text-green-400">Profissão *</Label>
        <Input
          id="profissao"
          value={formData.profissao}
          onChange={(e) => updateFormData('profissao', e.target.value)}
          className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
          placeholder="Sua profissão atual"
        />
      </div>
      
      <div>
        <Label htmlFor="estadoCivil" className="text-green-400">Estado civil *</Label>
        <Select value={formData.estadoCivil} onValueChange={(value) => updateFormData('estadoCivil', value)}>
          <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
            <SelectValue placeholder="Selecione seu estado civil" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-600">
            <SelectItem value="solteiro">Solteiro(a)</SelectItem>
            <SelectItem value="casado">Casado(a)</SelectItem>
            <SelectItem value="divorciado">Divorciado(a)</SelectItem>
            <SelectItem value="viuvo">Viúvo(a)</SelectItem>
            <SelectItem value="uniao-estavel">União Estável</SelectItem>
            <SelectItem value="separado">Separado(a)</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>

    {(formData.estadoCivil === 'casado' || formData.estadoCivil === 'uniao-estavel') && (
      <div>
        <Label htmlFor="regimeCasamento" className="text-green-400">Regime de casamento/união</Label>
        <Select value={formData.regimeCasamento} onValueChange={(value) => updateFormData('regimeCasamento', value)}>
          <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
            <SelectValue placeholder="Selecione o regime" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-600">
            <SelectItem value="comunhao-parcial">Comunhão Parcial de Bens</SelectItem>
            <SelectItem value="comunhao-universal">Comunhão Universal de Bens</SelectItem>
            <SelectItem value="separacao-total">Separação Total de Bens</SelectItem>
            <SelectItem value="participacao-final">Participação Final nos Aquestos</SelectItem>
            <SelectItem value="outro">Outro</SelectItem>
          </SelectContent>
        </Select>
        
        {formData.regimeCasamento === 'outro' && (
          <div className="mt-2">
            <Input
              value={formData.regimeCasamentoOutro}
              onChange={(e) => updateFormData('regimeCasamentoOutro', e.target.value)}
              className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
              placeholder="Especifique o regime de casamento"
            />
          </div>
        )}
      </div>
    )}

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="esportePreferido" className="text-green-400">Esporte preferido</Label>
        <Input
          id="esportePreferido"
          value={formData.esportePreferido}
          onChange={(e) => updateFormData('esportePreferido', e.target.value)}
          className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
          placeholder="Qual esporte você mais gosta?"
        />
      </div>
      
      <div>
        <Label htmlFor="hobbie" className="text-green-400">Hobbie</Label>
        <Input
          id="hobbie"
          value={formData.hobbie}
          onChange={(e) => updateFormData('hobbie', e.target.value)}
          className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
          placeholder="Seus hobbies favoritos"
        />
      </div>
    </div>
  </div>
)

const ConjugeSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    {(formData.estadoCivil === 'casado' || formData.estadoCivil === 'uniao-estavel') ? (
      <>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="nomeConjuge" className="text-green-400">Nome completo do cônjuge *</Label>
            <Input
              id="nomeConjuge"
              value={formData.nomeConjuge}
              onChange={(e) => updateFormData('nomeConjuge', e.target.value)}
              className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
              placeholder="Nome completo do cônjuge/companheiro(a)"
            />
          </div>
          
          <div>
            <Label htmlFor="dataNascimentoConjuge" className="text-green-400">Data de nascimento *</Label>
            <Input
              id="dataNascimentoConjuge"
              type="date"
              value={formData.dataNascimentoConjuge}
              onChange={(e) => updateFormData('dataNascimentoConjuge', e.target.value)}
              className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="profissaoConjuge" className="text-green-400">Profissão do cônjuge *</Label>
          <Input
            id="profissaoConjuge"
            value={formData.profissaoConjuge}
            onChange={(e) => updateFormData('profissaoConjuge', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="Profissão atual do cônjuge/companheiro(a)"
          />
        </div>

        <div>
          <Label className="text-green-400">Quem é o pilar financeiro da família? *</Label>
          <RadioGroup 
            value={formData.pilarFinanceiro} 
            onValueChange={(value) => updateFormData('pilarFinanceiro', value)}
            className="mt-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="eu" id="pilar-eu" className="border-green-500 text-green-500" />
              <Label htmlFor="pilar-eu" className="text-white">Eu</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="conjuge" id="pilar-conjuge" className="border-green-500 text-green-500" />
              <Label htmlFor="pilar-conjuge" className="text-white">Cônjuge/Companheiro(a)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="ambos" id="pilar-ambos" className="border-green-500 text-green-500" />
              <Label htmlFor="pilar-ambos" className="text-white">Ambos igualmente</Label>
            </div>
          </RadioGroup>
        </div>
      </>
    ) : (
      <div className="text-center py-8">
        <Heart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <p className="text-gray-400 text-lg">
          Esta seção é aplicável apenas para pessoas casadas ou em união estável.
        </p>
        <p className="text-gray-500 text-sm mt-2">
          Você pode pular para a próxima seção.
        </p>
      </div>
    )}
  </div>
)

const DependentesSection = ({ formData, updateFormData, addDependente, updateDependente, removeDependente }) => (
  <div className="space-y-6">
    <div className="flex justify-between items-center">
      <h3 className="text-lg font-semibold text-green-400">👨‍👩‍👧 Dependentes</h3>
      <Button 
        onClick={addDependente}
        variant="outline"
        className="border-green-500/50 text-green-400 hover:bg-green-500/10"
      >
        + Adicionar Dependente
      </Button>
    </div>

    {formData.dependentes.length === 0 ? (
      <div className="text-center py-8">
        <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <p className="text-gray-400 text-lg">Nenhum dependente adicionado</p>
        <p className="text-gray-500 text-sm mt-2">
          Clique em "Adicionar Dependente" para incluir informações sobre filhos, pais ou outros dependentes.
        </p>
      </div>
    ) : (
      <div className="space-y-6">
        {formData.dependentes.map((dependente, index) => (
          <Card key={index} className="bg-gray-800/50 border-gray-600">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-green-400 text-sm">
                  Dependente {index + 1}
                </CardTitle>
                {formData.dependentes.length > 1 && (
                  <Button 
                    onClick={() => removeDependente(index)}
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  >
                    Remover
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-green-400">Nome completo *</Label>
                  <Input
                    value={dependente.nome}
                    onChange={(e) => updateDependente(index, 'nome', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white focus:border-green-500"
                    placeholder="Nome do dependente"
                  />
                </div>
                
                <div>
                  <Label className="text-green-400">Grau de parentesco *</Label>
                  <Select 
                    value={dependente.grauParentesco} 
                    onValueChange={(value) => updateDependente(index, 'grauParentesco', value)}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white focus:border-green-500">
                      <SelectValue placeholder="Selecione o parentesco" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="filho">Filho(a)</SelectItem>
                      <SelectItem value="pai">Pai</SelectItem>
                      <SelectItem value="mae">Mãe</SelectItem>
                      <SelectItem value="irmao">Irmão/Irmã</SelectItem>
                      <SelectItem value="avo">Avô/Avó</SelectItem>
                      <SelectItem value="neto">Neto(a)</SelectItem>
                      <SelectItem value="sogro">Sogro(a)</SelectItem>
                      <SelectItem value="cunhado">Cunhado(a)</SelectItem>
                      <SelectItem value="genro-nora">Genro/Nora</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  {dependente.grauParentesco === 'outro' && (
                    <div className="mt-2">
                      <Input
                        value={dependente.grauParentescoOutro}
                        onChange={(e) => updateDependente(index, 'grauParentescoOutro', e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white focus:border-green-500"
                        placeholder="Especifique o grau de parentesco"
                      />
                    </div>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-green-400">Data de nascimento *</Label>
                  <Input
                    type="date"
                    value={dependente.dataNascimento}
                    onChange={(e) => updateDependente(index, 'dataNascimento', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white focus:border-green-500"
                  />
                </div>
                
                <div>
                  <Label className="text-green-400">Profissão/Ocupação</Label>
                  <Input
                    value={dependente.profissao}
                    onChange={(e) => updateDependente(index, 'profissao', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white focus:border-green-500"
                    placeholder="Profissão ou ocupação (ex: estudante)"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )}
  </div>
)

const PatrimonioRendaSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <h3 className="text-lg font-semibold text-green-400 mb-4">💰 Renda mensal média</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label className="text-green-400">Salários</Label>
          <Input
            value={formData.salarios}
            onChange={(e) => updateFormData('salarios', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="R$ 0,00"
          />
        </div>
        <div>
          <Label className="text-green-400">Gastos</Label>
          <Input
            value={formData.gastos}
            onChange={(e) => updateFormData('gastos', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="R$ 0,00"
          />
        </div>
        <div>
          <Label className="text-green-400">Renda total</Label>
          <Input
            value={formData.rendaTotal}
            onChange={(e) => updateFormData('rendaTotal', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="R$ 0,00"
          />
        </div>
      </div>
    </div>

    <div>
      <h3 className="text-lg font-semibold text-green-400 mb-4">📈 Outras fontes de renda</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label className="text-green-400">Distribuição de lucros</Label>
          <Input
            value={formData.distribuicaoLucros}
            onChange={(e) => updateFormData('distribuicaoLucros', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="R$ 0,00"
          />
        </div>
        <div>
          <Label className="text-green-400">Aluguéis</Label>
          <Input
            value={formData.alugueis}
            onChange={(e) => updateFormData('alugueis', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="R$ 0,00"
          />
        </div>
      </div>
      
      <div className="mt-4">
        <Label className="text-green-400">Outras fontes de renda?</Label>
        <RadioGroup 
          value={formData.outrasRendas} 
          onValueChange={(value) => updateFormData('outrasRendas', value)}
          className="mt-2"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="sim" id="outras-sim" className="border-green-500 text-green-500" />
            <Label htmlFor="outras-sim" className="text-white">Sim</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="nao" id="outras-nao" className="border-green-500 text-green-500" />
            <Label htmlFor="outras-nao" className="text-white">Não</Label>
          </div>
        </RadioGroup>
        
        {formData.outrasRendas === 'sim' && (
          <div className="mt-2">
            <Textarea
              value={formData.outrasRendasDescricao}
              onChange={(e) => updateFormData('outrasRendasDescricao', e.target.value)}
              className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
              placeholder="Descreva as outras fontes de renda..."
              rows={3}
            />
          </div>
        )}
      </div>
    </div>

    <div>
      <h3 className="text-lg font-semibold text-green-400 mb-4">🏠 Patrimônio</h3>
      <div className="space-y-4">
        <div>
          <Label className="text-green-400">Patrimônio relevante (imóveis, empresas, participações, outros)</Label>
          <Textarea
            value={formData.patrimonioRelevante}
            onChange={(e) => updateFormData('patrimonioRelevante', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="Descreva seu patrimônio relevante..."
            rows={3}
          />
        </div>
        
        <div>
          <Label className="text-green-400">Patrimônio fora da XP (Instituição / Valor / Ativos)</Label>
          <Textarea
            value={formData.patrimonioForaXP}
            onChange={(e) => updateFormData('patrimonioForaXP', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="Ex: Banco do Brasil / R$ 50.000 / Poupança e CDB"
            rows={3}
          />
        </div>
        
        <div>
          <Label className="text-green-400">Dívidas/financiamentos (valores e prazos)</Label>
          <Textarea
            value={formData.dividas}
            onChange={(e) => updateFormData('dividas', e.target.value)}
            className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
            placeholder="Descreva suas dívidas e financiamentos..."
            rows={3}
          />
        </div>
      </div>
    </div>
  </div>
)

const ExperienciaInvestidorSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <Label className="text-green-400">Já investe? Onde e em quais produtos?</Label>
      <Textarea
        value={formData.jaInveste}
        onChange={(e) => updateFormData('jaInveste', e.target.value)}
        className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
        placeholder="Ex: Sim, invisto na XP em ações, FIIs e CDBs..."
        rows={3}
      />
    </div>

    <div>
      <Label className="text-green-400">Grau de conhecimento *</Label>
      <Select value={formData.grauConhecimento} onValueChange={(value) => updateFormData('grauConhecimento', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione seu nível de conhecimento" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="iniciante">Iniciante</SelectItem>
          <SelectItem value="intermediario">Intermediário</SelectItem>
          <SelectItem value="avancado">Avançado</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Tolerância ao risco *</Label>
      <Select value={formData.toleranciaRisco} onValueChange={(value) => updateFormData('toleranciaRisco', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione seu perfil de risco" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="conservador">Conservador</SelectItem>
          <SelectItem value="moderado">Moderado</SelectItem>
          <SelectItem value="arrojado">Arrojado</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Como reagiu em crises do mercado?</Label>
      <Textarea
        value={formData.reacaoCrises}
        onChange={(e) => updateFormData('reacaoCrises', e.target.value)}
        className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
        placeholder="Descreva como você reagiu em momentos de crise no mercado..."
        rows={3}
      />
    </div>
  </div>
)

const ObjetivosFinanceirosSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <Label className="text-green-400">Objetivo principal dos investimentos *</Label>
      <Select value={formData.objetivoPrincipal} onValueChange={(value) => updateFormData('objetivoPrincipal', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione o objetivo principal" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="aposentadoria">Aposentadoria</SelectItem>
          <SelectItem value="reserva-emergencia">Reserva de Emergência</SelectItem>
          <SelectItem value="compra-imovel">Compra de Imóvel</SelectItem>
          <SelectItem value="educacao-filhos">Educação dos Filhos</SelectItem>
          <SelectItem value="viagem">Viagem</SelectItem>
          <SelectItem value="crescimento-patrimonio">Crescimento do Patrimônio</SelectItem>
          <SelectItem value="renda-passiva">Renda Passiva</SelectItem>
          <SelectItem value="outro">Outro</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Prazo definido para os objetivos?</Label>
      <Input
        value={formData.prazoDefinido}
        onChange={(e) => updateFormData('prazoDefinido', e.target.value)}
        className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
        placeholder="Ex: 5 anos, 10 anos, longo prazo..."
      />
    </div>

    <div>
      <Label className="text-green-400">Rentabilidade esperada</Label>
      <Select value={formData.rentabilidadeEsperada} onValueChange={(value) => updateFormData('rentabilidadeEsperada', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione a rentabilidade esperada" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="ate-cdi">Até 100% do CDI</SelectItem>
          <SelectItem value="cdi-plus">CDI + 2% a 5%</SelectItem>
          <SelectItem value="inflacao-plus">Inflação + 5% a 8%</SelectItem>
          <SelectItem value="acima-10">Acima de 10% ao ano</SelectItem>
          <SelectItem value="nao-sei">Não sei informar</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Busca renda passiva ou crescimento de capital? *</Label>
      <RadioGroup 
        value={formData.buscaRenda} 
        onValueChange={(value) => updateFormData('buscaRenda', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="renda-passiva" id="renda-passiva" className="border-green-500 text-green-500" />
          <Label htmlFor="renda-passiva" className="text-white">Renda Passiva (dividendos, juros)</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="crescimento" id="crescimento" className="border-green-500 text-green-500" />
          <Label htmlFor="crescimento" className="text-white">Crescimento de Capital</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="ambos" id="ambos-obj" className="border-green-500 text-green-500" />
          <Label htmlFor="ambos-obj" className="text-white">Ambos</Label>
        </div>
      </RadioGroup>
    </div>
  </div>
)

const LiquidezNecessidadesSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <Label className="text-green-400">Precisa de liquidez no curto prazo? *</Label>
      <RadioGroup 
        value={formData.precisaLiquidez} 
        onValueChange={(value) => updateFormData('precisaLiquidez', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="sim" id="liquidez-sim" className="border-green-500 text-green-500" />
          <Label htmlFor="liquidez-sim" className="text-white">Sim</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="nao" id="liquidez-nao" className="border-green-500 text-green-500" />
          <Label htmlFor="liquidez-nao" className="text-white">Não</Label>
        </div>
      </RadioGroup>
    </div>

    <div>
      <Label className="text-green-400">Por quanto tempo pode deixar o dinheiro investido sem mexer?</Label>
      <Select value={formData.tempoInvestido} onValueChange={(value) => updateFormData('tempoInvestido', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione o prazo" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="ate-6-meses">Até 6 meses</SelectItem>
          <SelectItem value="6-12-meses">6 a 12 meses</SelectItem>
          <SelectItem value="1-2-anos">1 a 2 anos</SelectItem>
          <SelectItem value="2-5-anos">2 a 5 anos</SelectItem>
          <SelectItem value="acima-5-anos">Acima de 5 anos</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Alguma restrição de produtos (ações, criptos, etc.)?</Label>
      <Textarea
        value={formData.restricoesProdutos}
        onChange={(e) => updateFormData('restricoesProdutos', e.target.value)}
        className="bg-gray-800 border-gray-600 text-white focus:border-green-500"
        placeholder="Ex: Não invisto em criptomoedas por questões religiosas..."
        rows={3}
      />
    </div>
  </div>
)

const TributacaoSucessorioSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <Label className="text-green-400">Prefere estratégias fiscalmente mais eficientes? *</Label>
      <RadioGroup 
        value={formData.estrategiasFiscais} 
        onValueChange={(value) => updateFormData('estrategiasFiscais', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="sim" id="fiscal-sim" className="border-green-500 text-green-500" />
          <Label htmlFor="fiscal-sim" className="text-white">Sim, priorizo eficiência fiscal</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="nao" id="fiscal-nao" className="border-green-500 text-green-500" />
          <Label htmlFor="fiscal-nao" className="text-white">Não, foco apenas na rentabilidade</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="indiferente" id="fiscal-indiferente" className="border-green-500 text-green-500" />
          <Label htmlFor="fiscal-indiferente" className="text-white">Indiferente</Label>
        </div>
      </RadioGroup>
    </div>

    <div>
      <Label className="text-green-400">Interesse em planejamento sucessório?</Label>
      <RadioGroup 
        value={formData.planejamentoSucessorio} 
        onValueChange={(value) => updateFormData('planejamentoSucessorio', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="sim" id="sucessorio-sim" className="border-green-500 text-green-500" />
          <Label htmlFor="sucessorio-sim" className="text-white">Sim, tenho interesse</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="nao" id="sucessorio-nao" className="border-green-500 text-green-500" />
          <Label htmlFor="sucessorio-nao" className="text-white">Não tenho interesse</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="futuro" id="sucessorio-futuro" className="border-green-500 text-green-500" />
          <Label htmlFor="sucessorio-futuro" className="text-white">Talvez no futuro</Label>
        </div>
      </RadioGroup>
    </div>

    <div>
      <Label className="text-green-400">Já possui testamento ou plano de herança?</Label>
      <RadioGroup 
        value={formData.testamento} 
        onValueChange={(value) => updateFormData('testamento', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="sim" id="testamento-sim" className="border-green-500 text-green-500" />
          <Label htmlFor="testamento-sim" className="text-white">Sim, já possuo</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="nao" id="testamento-nao" className="border-green-500 text-green-500" />
          <Label htmlFor="testamento-nao" className="text-white">Não possuo</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="planejando" id="testamento-planejando" className="border-green-500 text-green-500" />
          <Label htmlFor="testamento-planejando" className="text-white">Estou planejando fazer</Label>
        </div>
      </RadioGroup>
    </div>
  </div>
)

const ComportamentoRelacionamentoSection = ({ formData, updateFormData }) => (
  <div className="space-y-6">
    <div>
      <Label className="text-green-400">Forma preferida de comunicação *</Label>
      <Select value={formData.comunicacaoPreferida} onValueChange={(value) => updateFormData('comunicacaoPreferida', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione a forma preferida" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="whatsapp">WhatsApp</SelectItem>
          <SelectItem value="email">E-mail</SelectItem>
          <SelectItem value="telefone">Telefone</SelectItem>
          <SelectItem value="presencial">Presencial</SelectItem>
          <SelectItem value="video-chamada">Videochamada</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Frequência desejada de atualização sobre a carteira *</Label>
      <Select value={formData.frequenciaAtualizacao} onValueChange={(value) => updateFormData('frequenciaAtualizacao', value)}>
        <SelectTrigger className="bg-gray-800 border-gray-600 text-white focus:border-green-500">
          <SelectValue placeholder="Selecione a frequência" />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-600">
          <SelectItem value="diaria">Diária</SelectItem>
          <SelectItem value="semanal">Semanal</SelectItem>
          <SelectItem value="quinzenal">Quinzenal</SelectItem>
          <SelectItem value="mensal">Mensal</SelectItem>
          <SelectItem value="trimestral">Trimestral</SelectItem>
          <SelectItem value="quando-necessario">Apenas quando necessário</SelectItem>
        </SelectContent>
      </Select>
    </div>

    <div>
      <Label className="text-green-400">Prefere decidir sozinho ou com direcionamento do assessor? *</Label>
      <RadioGroup 
        value={formData.decisaoInvestimento} 
        onValueChange={(value) => updateFormData('decisaoInvestimento', value)}
        className="mt-2"
      >
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="sozinho" id="decisao-sozinho" className="border-green-500 text-green-500" />
          <Label htmlFor="decisao-sozinho" className="text-white">Prefiro decidir sozinho</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="assessor" id="decisao-assessor" className="border-green-500 text-green-500" />
          <Label htmlFor="decisao-assessor" className="text-white">Prefiro direcionamento do assessor</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="colaborativo" id="decisao-colaborativo" className="border-green-500 text-green-500" />
          <Label htmlFor="decisao-colaborativo" className="text-white">Decisão colaborativa</Label>
        </div>
      </RadioGroup>
    </div>

    <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mt-6">
      <h3 className="text-green-400 font-semibold mb-2">🎉 Parabéns!</h3>
      <p className="text-gray-300">
        Você chegou ao final do questionário. Suas informações nos ajudarão a criar uma estratégia de investimentos personalizada para seus objetivos.
      </p>
    </div>
  </div>
)

export default App
